<!-- rodapé --->
<footer  class="sticky-footer">
	<div class="container">
		<div class="text-center">
			<small>&copy;AbgSoluções -  <?=date("Y")?> - abgsolucoes.tec.br </small>
		</div>
	</div>
</footer>