<?php
require "model/PesquisaPorDataReceb.php";

class crtPesquisaPorDataReceb {

	public function PesquisaPorDataReceb()
	{	
		include "view/pesquisa-por-data-receb.php";
	}
}

?>