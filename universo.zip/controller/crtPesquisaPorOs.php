<?php
require "model/PesquisaPorOs.php";

class crtPesquisaPorOs {

	public function pesquisaPorOs()
	{	
		include "view/pesquisa-por-os.php";
	}
}

?>