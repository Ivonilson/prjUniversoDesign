<?php
require "model/Historico.php";

class crtHistorico {

	public function historico()
	{	
		include "view/historico.php";
	}
}

?>
