<?php
require "model/PesquisaPorDataAgendamento.php";

class crtPesquisaPorDataAgendamento {

	public function PesquisaPorDataAgendamento()
	{	
		include "view/pesquisa-por-data-agendamento.php";
	}
}

?>